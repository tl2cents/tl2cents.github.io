import os
import utils
import special
import secret

cipher = utils.ToyCBC(key=os.urandom(16), iv=os.urandom(16), sbox=special.sbox)
flag_from_dbt = secret.flag
noise_from_rec = os.urandom(32)

enc1 = cipher.encrypt(flag_from_dbt)
enc2 = cipher.encrypt(noise_from_rec)

print(f"enc1 = {enc1.hex()}\n"
      f"enc2 = {enc2.hex()}\n"
      f"noise = {noise_from_rec.hex()}")

'''
enc1 = fedca0ccdb5a125445609beafe9e40a792a3b454fd85188456c4b17f2500a330227cae0b8942b3f46084011a1e7ec8482f6ca6894ced646b334ade64be093ca9
enc2 = 1af90348006ec43b8983e9e44a6550fe2cdbf86fdb931ab61438c6535a786ee68a4b3a789f3047e712422124fa91d74c
noise = 4d8514f7de400dfabfd33cc6a7c46f7c293b0c1f38ac02dff40554bd92b67e93
'''