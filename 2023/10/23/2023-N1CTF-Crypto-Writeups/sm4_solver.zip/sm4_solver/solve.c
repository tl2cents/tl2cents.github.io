#include<stdio.h> 
#include<stdlib.h>
#include <string.h>
#include "sm4.h"

#ifndef PUT_UINT32_BE
#define PUT_UINT32_BE(n, b, i)                     \
    {                                              \
        (b)[(i)] = (unsigned char)((n) >> 24);     \
        (b)[(i) + 1] = (unsigned char)((n) >> 16); \
        (b)[(i) + 2] = (unsigned char)((n) >> 8);  \
        (b)[(i) + 3] = (unsigned char)((n));       \
    }
#endif

#ifndef GET_UINT32_BE
#define GET_UINT32_BE(n, b, i)                                                                                                                        \
    {                                                                                                                                                 \
        (n) = ((unsigned int)(b)[(i)] << 24) | ((unsigned int)(b)[(i) + 1] << 16) | ((unsigned int)(b)[(i) + 2] << 8) | ((unsigned int)(b)[(i) + 3]); \
    }
#endif

//  'e5a304ea2ffc53a1ff94337c2b2ae536 8b46c6da3cc37f8438eb967b29249d4e' 
//  '6733baa353d4cfc4ff94337c58dc7fdb d6df83f4fbf6e5e838eb967b98d7e8d3' 
//  'e77dbfe7868701fbd7072e6358dc7fdb a067d296707bad1b0f4541dc98d7e8d3' 
//  '54b772d532556d5573a6ab667c9ff768 57b5efc3b62130668e46a79b163138e4'
//  '47339f6738dd9f4c9581fbd496dde76e a320d95b457e0373cddb910acc41fe35'
unsigned char cts [5][16] = {
    {0xe5, 0xa3, 0x04, 0xea, 0x2f, 0xfc, 0x53, 0xa1, 0xff, 0x94, 0x33, 0x7c, 0x2b, 0x2a, 0xe5, 0x36},
    {0x67, 0x33, 0xba, 0xa3, 0x53, 0xd4, 0xcf, 0xc4, 0xff, 0x94, 0x33, 0x7c, 0x58, 0xdc, 0x7f, 0xdb},
    {0xe7, 0x7d, 0xbf, 0xe7, 0x86, 0x87, 0x01, 0xfb, 0xd7, 0x07, 0x2e, 0x63, 0x58, 0xdc, 0x7f, 0xdb},
    {0x54, 0xb7, 0x72, 0xd5, 0x32, 0x55, 0x6d, 0x55, 0x73, 0xa6, 0xab, 0x66, 0x7c, 0x9f, 0xf7, 0x68},
    {0x47, 0x33, 0x9f, 0x67, 0x38, 0xdd, 0x9f, 0x4c, 0x95, 0x81, 0xfb, 0xd4, 0x96, 0xdd, 0xe7, 0x6e}
};

unsigned char cts2[5][16] = {
    {0x8b, 0x46, 0xc6, 0xda, 0x3c, 0xc3, 0x7f, 0x84, 0x38, 0xeb, 0x96, 0x7b, 0x29, 0x24, 0x9d, 0x4e},
    {0xd6, 0xdf, 0x83, 0xf4, 0xfb, 0xf6, 0xe5, 0xe8, 0x38, 0xeb, 0x96, 0x7b, 0x98, 0xd7, 0xe8, 0xd3},
    {0xa0, 0x67, 0xd2, 0x96, 0x70, 0x7b, 0xad, 0x1b, 0x0f, 0x45, 0x41, 0xdc, 0x98, 0xd7, 0xe8, 0xd3},
    {0x57, 0xb5, 0xef, 0xc3, 0xb6, 0x21, 0x30, 0x66, 0x8e, 0x46, 0xa7, 0x9b, 0x16, 0x31, 0x38, 0xe4},
    {0xa3, 0x20, 0xd9, 0x5b, 0x45, 0x7e, 0x03, 0x73, 0xcd, 0xdb, 0x91, 0x0a, 0xcc, 0x41, 0xfe, 0x35}
};

unsigned int rk[32] = {259964877, 1625404762, 3341115610, 3893109082, 2377830859, 1988099899, 1807063484, 3359657580, 2971646999, 2846555909, 2335858833, 1109756217, 756566101, 3090167391, 3710076796, 1384239525, 3682223831, 1829915426, 621403234, 2547173928, 324596784, 3494609092, 1766040629, 2473160961, 1607723531, 1818615550, 3262867708, 2320221348, 2670354797, 2579313595, 1496211628, 2818065599};
unsigned int rki[32] = {2818065599, 1496211628, 2579313595, 2670354797, 2320221348, 3262867708, 1818615550, 1607723531, 2473160961, 1766040629, 3494609092, 324596784, 2547173928, 621403234, 1829915426, 3682223831, 1384239525, 3710076796, 3090167391, 756566101, 1109756217, 2335858833, 2846555909, 2971646999, 3359657580, 1807063484, 1988099899, 2377830859, 3893109082, 3341115610, 1625404762, 259964877};



int main(int argc, char *argv[])
{
    unsigned char plaintext[16] = {0x00};
    unsigned char ciphertext1[16] = {0x00};

    inverse_one_round_raw(cts[0], rki[0], 1);
    inverse_one_round_raw(cts2[0], rki[0], 1);

    for(int i = 1; i<32; i++)
    {
        inverse_one_round_raw(cts[0], rki[i], 0);
        inverse_one_round_raw(cts2[0], rki[i], 0);
    }
    

    printf("plaintext: ");
    for(int i = 0; i<16; i++)
    {
        printf("%02x", cts[0][i]);
    }

    for(int i = 0; i<16; i++)
    {
        printf("%02x", cts2[0][i]);
    }
    printf("\n");
    // sm4_context ctx;
    // sm4_set_roundkey_dec(&ctx, rk);
}