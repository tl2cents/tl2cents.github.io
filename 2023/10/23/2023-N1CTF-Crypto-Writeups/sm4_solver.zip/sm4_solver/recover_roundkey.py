# intmod=0x100000001
# bytemod=0x101
# default: mod x^32+1
def add(a, b):
    return a ^ b


def mul(a, b):
    ret = 0
    while b:
        if b & 1:
            ret ^= a
            while ret >> 32:
                ret = (ret | (ret >> 32)) & 0xffffffff
        b >>= 1
        a <<= 1
    return ret


def le(a, b):
    return a.bit_length() < b.bit_length()


def div(a, b):
    assert (b)
    ans = 0
    while not le(a, b):
        h = a.bit_length()-b.bit_length()
        hbit = a.bit_length()-1
        if a >> hbit:
            ans |= (1 << h)
            a ^= (b << h)
    return (ans, a)


def GFexgcd(a, b):  # mod x^32+1
    if b == 0:
        return 1, 0, a
    quo, res = div(a, b)
    x, y, g = GFexgcd(b, res)
    x, y = y, add(x, mul(quo, y))
    return x, y, g


if __name__ == "__main__":
    # a, b, = 3, 8
    # x, y, g = GFexgcd(a, b)
    # print(add(mul(a, x), mul(b, y)))
    # a, b = 0x802001, 0x100000001  # x^32+x^13+x^0
    # x, y, g = GFexgcd(a, b)
    # print(add(mul(a, x), mul(b, y)))
    # print("reverse of {} is {}".format(hex(a), hex(x)))
    # reverse0x802001 = x
    from util import expand_key, SM4_CK, SM4_BOXES_TABLE, round_key, i2l, l2i

    # def tau(k):
    #        ar = [SM4_BOXES_TABLE[i] for i in i2l(k)]
    #        b = l2i(ar)
    #        return b
    # rk = expand_key(list(range(16)))
    # print(rk[-5:])
    # print(add(rk[-1], round_key(SM4_CK[-1] ^ rk[-2] ^ rk[-3] ^ rk[-4])))
    # demo end
    # print("="*80)

    # last4=rk[-4:]#input()
    last4 = [0xa7f844bf, 0x592e60ac, 0x99bd33bb, 0x9f2a616d][::-1]
    for i in range(32):
        last4 = [add(last4[3], round_key(
            SM4_CK[-i-1] ^ last4[0] ^ last4[1] ^ last4[2]))]+last4
    print(last4[4:][::-1])
    # print(rk)
    # print(rk==last4[4:])
