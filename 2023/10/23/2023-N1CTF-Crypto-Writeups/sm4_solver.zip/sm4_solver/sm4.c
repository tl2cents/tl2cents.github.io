/*
 * SM4 Encryption alogrithm (SMS4 algorithm)
 * GM/T 0002-2012 Chinese National Standard ref:http://www.oscca.gov.cn/
 * thanks to Xyssl
 * thnaks and refers to http://hi.baidu.com/numax/blog/item/80addfefddfb93e4cf1b3e61.html
 * author:goldboar
 * email:goldboar@163.com
 * 2012-4-20
 */

// Test vector 1
// plain: 01 23 45 67 89 ab cd ef fe dc ba 98 76 54 32 10
// key:   01 23 45 67 89 ab cd ef fe dc ba 98 76 54 32 10
// 	   round key and temp computing result:
// 	   rk[ 0] = f12186f9 X[ 0] = 27fad345
// 		   rk[ 1] = 41662b61 X[ 1] = a18b4cb2
// 		   rk[ 2] = 5a6ab19a X[ 2] = 11c1e22a
// 		   rk[ 3] = 7ba92077 X[ 3] = cc13e2ee
// 		   rk[ 4] = 367360f4 X[ 4] = f87c5bd5
// 		   rk[ 5] = 776a0c61 X[ 5] = 33220757
// 		   rk[ 6] = b6bb89b3 X[ 6] = 77f4c297
// 		   rk[ 7] = 24763151 X[ 7] = 7a96f2eb
// 		   rk[ 8] = a520307c X[ 8] = 27dac07f
// 		   rk[ 9] = b7584dbd X[ 9] = 42dd0f19
// 		   rk[10] = c30753ed X[10] = b8a5da02
// 		   rk[11] = 7ee55b57 X[11] = 907127fa
// 		   rk[12] = 6988608c X[12] = 8b952b83
// 		   rk[13] = 30d895b7 X[13] = d42b7c59
// 		   rk[14] = 44ba14af X[14] = 2ffc5831
// 		   rk[15] = 104495a1 X[15] = f69e6888
// 		   rk[16] = d120b428 X[16] = af2432c4
// 		   rk[17] = 73b55fa3 X[17] = ed1ec85e
// 		   rk[18] = cc874966 X[18] = 55a3ba22
// 		   rk[19] = 92244439 X[19] = 124b18aa
// 		   rk[20] = e89e641f X[20] = 6ae7725f
// 		   rk[21] = 98ca015a X[21] = f4cba1f9
// 		   rk[22] = c7159060 X[22] = 1dcdfa10
// 		   rk[23] = 99e1fd2e X[23] = 2ff60603
// 		   rk[24] = b79bd80c X[24] = eff24fdc
// 		   rk[25] = 1d2115b0 X[25] = 6fe46b75
// 		   rk[26] = 0e228aeb X[26] = 893450ad
// 		   rk[27] = f1780c81 X[27] = 7b938f4c
// 		   rk[28] = 428d3654 X[28] = 536e4246
// 		   rk[29] = 62293496 X[29] = 86b3e94f
// 		   rk[30] = 01cf72e5 X[30] = d206965e
// 		   rk[31] = 9124a012 X[31] = 681edf34
// cypher: 68 1e df 34 d2 06 96 5e 86 b3 e9 4f 53 6e 42 46
//
// test vector 2
// the same key and plain 1000000 times coumpting
// plain:  01 23 45 67 89 ab cd ef fe dc ba 98 76 54 32 10
// key:    01 23 45 67 89 ab cd ef fe dc ba 98 76 54 32 10
// cypher: 59 52 98 c7 c6 fd 27 1f 04 02 f8 04 c3 3d 3f 66

#include "sm4.h"
#include <string.h>
#include <stdio.h>

/*
 * 32-bit integer manipulation macros (big endian)
 */
#ifndef GET_UINT32_BE
#define GET_UINT32_BE(n, b, i)                                                                                                                        \
    {                                                                                                                                                 \
        (n) = ((unsigned int)(b)[(i)] << 24) | ((unsigned int)(b)[(i) + 1] << 16) | ((unsigned int)(b)[(i) + 2] << 8) | ((unsigned int)(b)[(i) + 3]); \
    }
#endif

#ifndef PUT_UINT32_BE
#define PUT_UINT32_BE(n, b, i)                     \
    {                                              \
        (b)[(i)] = (unsigned char)((n) >> 24);     \
        (b)[(i) + 1] = (unsigned char)((n) >> 16); \
        (b)[(i) + 2] = (unsigned char)((n) >> 8);  \
        (b)[(i) + 3] = (unsigned char)((n));       \
    }
#endif

/*
 *rotate shift left marco definition
 *
 */
#define SHL(x, n) (((x)&0xFFFFFFFF) << n)
#define ROTL(x, n) (SHL((x), n) | ((x) >> (32 - n)))

// rotl8 = lambda x, n: ((x << n) & 0xff) | ((x >> (8-n)) & 0xff)
// #define ROTL8(x,n) (((x) << n) & 0xff) | (((x) >> (8-n)) & 0xff)

#define SWAP(a, b)          \
    {                       \
        unsigned int t = a; \
        a = b;              \
        b = t;              \
        t = 0;              \
    }

unsigned char rot18(unsigned char x, unsigned char n)
{
    return (((x << n) & 0xff) | ((x >> (8 - n)) & 0xff)) & 0xff;
}

/*
 * Expanded SM4 S-boxes
 /* Sbox table: 8bits input convert to 8 bits output*/

static const unsigned char SboxTable[16][16] =
    {
        {0xd6, 0x90, 0xe9, 0xfe, 0xcc, 0xe1, 0x3d, 0xb7, 0x16, 0xb6, 0x14, 0xc2, 0x28, 0xfb, 0x2c, 0x05},
        {0x2b, 0x67, 0x9a, 0x76, 0x2a, 0xbe, 0x04, 0xc3, 0xaa, 0x44, 0x13, 0x26, 0x49, 0x86, 0x06, 0x99},
        {0x9c, 0x42, 0x50, 0xf4, 0x91, 0xef, 0x98, 0x7a, 0x33, 0x54, 0x0b, 0x43, 0xed, 0xcf, 0xac, 0x62},
        {0xe4, 0xb3, 0x1c, 0xa9, 0xc9, 0x08, 0xe8, 0x95, 0x80, 0xdf, 0x94, 0xfa, 0x75, 0x8f, 0x3f, 0xa6},
        {0x47, 0x07, 0xa7, 0xfc, 0xf3, 0x73, 0x17, 0xba, 0x83, 0x59, 0x3c, 0x19, 0xe6, 0x85, 0x4f, 0xa8},
        {0x68, 0x6b, 0x81, 0xb2, 0x71, 0x64, 0xda, 0x8b, 0xf8, 0xeb, 0x0f, 0x4b, 0x70, 0x56, 0x9d, 0x35},
        {0x1e, 0x24, 0x0e, 0x5e, 0x63, 0x58, 0xd1, 0xa2, 0x25, 0x22, 0x7c, 0x3b, 0x01, 0x21, 0x78, 0x87},
        {0xd4, 0x00, 0x46, 0x57, 0x9f, 0xd3, 0x27, 0x52, 0x4c, 0x36, 0x02, 0xe7, 0xa0, 0xc4, 0xc8, 0x9e},
        {0xea, 0xbf, 0x8a, 0xd2, 0x40, 0xc7, 0x38, 0xb5, 0xa3, 0xf7, 0xf2, 0xce, 0xf9, 0x61, 0x15, 0xa1},
        {0xe0, 0xae, 0x5d, 0xa4, 0x9b, 0x34, 0x1a, 0x55, 0xad, 0x93, 0x32, 0x30, 0xf5, 0x8c, 0xb1, 0xe3},
        {0x1d, 0xf6, 0xe2, 0x2e, 0x82, 0x66, 0xca, 0x60, 0xc0, 0x29, 0x23, 0xab, 0x0d, 0x53, 0x4e, 0x6f},
        {0xd5, 0xdb, 0x37, 0x45, 0xde, 0xfd, 0x8e, 0x2f, 0x03, 0xff, 0x6a, 0x72, 0x6d, 0x6c, 0x5b, 0x51},
        {0x8d, 0x1b, 0xaf, 0x92, 0xbb, 0xdd, 0xbc, 0x7f, 0x11, 0xd9, 0x5c, 0x41, 0x1f, 0x10, 0x5a, 0xd8},
        {0x0a, 0xc1, 0x31, 0x88, 0xa5, 0xcd, 0x7b, 0xbd, 0x2d, 0x74, 0xd0, 0x12, 0xb8, 0xe5, 0xb4, 0xb0},
        {0x89, 0x69, 0x97, 0x4a, 0x0c, 0x96, 0x77, 0x7e, 0x65, 0xb9, 0xf1, 0x09, 0xc5, 0x6e, 0xc6, 0x84},
        {0x18, 0xf0, 0x7d, 0xec, 0x3a, 0xdc, 0x4d, 0x20, 0x79, 0xee, 0x5f, 0x3e, 0xd7, 0xcb, 0x39, 0x48}};

static const unsigned char SM4_BOXES_TABLE_INVERSE[256] = {113, 108, 122, 184, 22, 15, 30, 65, 53, 235, 208, 42, 228, 172, 98, 90, 205, 200, 219, 26, 10, 142, 8, 70, 240, 75, 150, 193, 50, 160, 96, 204, 247, 109, 105, 170, 97, 104, 27, 118, 12, 169, 20, 16, 14, 216, 163, 183, 155, 210, 154, 40, 149, 95, 121, 178, 134, 254, 244, 107, 74, 6, 251, 62, 132, 203, 33, 43, 25, 179, 114, 64, 255, 28, 227, 91, 120, 246, 174, 78, 34, 191, 119, 173, 41, 151, 93, 115, 101, 73, 206, 190, 202, 146, 99, 250, 167, 141, 47, 100, 85, 232, 165, 17, 80, 225, 186, 81, 189, 188, 237, 175, 92, 84, 187, 69, 217, 60, 19, 230, 110, 248, 39, 214, 106, 242, 231, 199, 56, 82, 164, 72, 239, 77, 29, 111, 211, 224, 130, 87, 157, 192, 182, 61, 1, 36, 195, 153, 58, 55, 229, 226, 38, 31, 18, 148, 32, 94, 127, 116, 124, 143, 103, 136, 147, 212, 63, 66, 79, 51, 24, 171, 46, 152, 145, 194, 223, 158, 83, 49, 222, 135, 9, 7, 220, 233, 71, 196, 198, 215, 21, 129, 168, 209, 11, 23, 125, 236, 238, 133, 126, 52, 166, 253, 4, 213, 139, 45, 218, 102, 131, 117, 112, 176, 0, 252, 207, 201, 86, 177, 245, 197, 180, 57, 144, 5, 162, 159, 48, 221, 76, 123, 54, 2, 128, 89, 243, 44, 249, 37, 241, 234, 138, 68, 35, 156, 161, 137, 88, 140, 59, 13, 67, 181, 3, 185};

static const unsigned char Dance_Box[4][256] = {
    {46, 38, 43, 106, 114, 176, 12, 69, 1, 21, 82, 27, 184, 109, 170, 0, 179, 25, 4, 145, 33, 61, 66, 223, 85, 238, 22, 23, 59, 64, 19, 174, 180, 240, 111, 128, 187, 65, 72, 35, 77, 221, 157, 172, 13, 197, 44, 229, 226, 130, 220, 49, 198, 24, 103, 76, 39, 211, 191, 115, 165, 206, 30, 7, 98, 156, 205, 181, 89, 252, 58, 138, 253, 104, 212, 236, 54, 224, 166, 155, 118, 8, 93, 140, 28, 95, 225, 248, 80, 182, 112, 63, 192, 116, 47, 217, 91, 84, 144, 53, 124, 117, 16, 73, 218, 254, 188, 18, 11, 107, 222, 5, 52, 129, 194, 173, 81, 9, 137, 246, 242, 143, 175, 147, 74, 195, 41, 133, 207, 120, 92, 17, 164, 169, 171, 48, 241, 57, 31, 83, 55, 96, 29, 185, 68, 232, 70, 148, 243, 209, 100, 214, 37, 244, 219, 131, 203, 139, 126, 183, 167, 199, 101, 159, 50, 230, 168, 45, 149, 123, 119, 87, 134, 75, 127, 67, 250, 228, 247, 135, 113, 60, 62, 177, 150, 121, 162, 227, 142, 34, 178, 42, 15, 160, 161, 216, 235, 234, 163, 186, 154, 141, 233, 208, 78, 151, 204, 190, 86, 152, 245, 239, 108, 196, 158, 210, 99, 237, 251, 3, 40, 90, 125, 132, 36, 215, 193, 71, 255, 200, 102, 56, 32, 136, 146, 79, 97, 110, 249, 20, 202, 231, 122, 88, 94, 6, 153, 105, 14, 10, 2, 201, 189, 213, 51, 26},
    {246, 56, 103, 21, 181, 105, 216, 118, 145, 183, 169, 211, 27, 242, 190, 162, 237, 179, 244, 199, 206, 35, 120, 38, 95, 133, 25, 231, 3, 70, 40, 238, 223, 45, 127, 245, 4, 15, 250, 11, 52, 215, 142, 129, 167, 191, 61, 241, 188, 226, 249, 146, 221, 184, 104, 109, 157, 39, 176, 114, 236, 240, 254, 253, 251, 158, 198, 37, 42, 19, 87, 230, 153, 43, 77, 76, 208, 26, 32, 18, 150, 195, 122, 90, 80, 148, 197, 44, 83, 51, 166, 75, 88, 73, 64, 252, 20, 119, 46, 201, 196, 121, 222, 115, 22, 128, 164, 102, 97, 5, 217, 172, 177, 81, 58, 234, 168, 60, 29, 124, 147, 101, 224, 151, 130, 65, 98, 225, 155, 91, 108, 152, 140, 219, 9, 24, 189, 203, 138, 160, 59, 48, 193, 14, 69, 159, 233, 53, 135, 143, 33, 165, 41, 132, 57, 187, 227, 93, 200, 1, 0, 149, 137, 194, 23, 117, 170, 247, 17, 255, 92, 205, 47, 213, 136, 66, 2, 209, 6, 110, 78, 63, 28, 74, 235, 229, 30, 139, 154, 94, 131, 49, 86, 185, 163, 79, 68, 8, 72, 174, 99, 111, 141, 107, 210, 34, 207, 239, 106, 144, 228, 186, 89, 204, 55, 54, 171, 161, 100, 16, 13, 7, 50, 182, 112, 173, 212, 31, 214, 85, 156, 180, 175, 116, 248, 243, 36, 82, 134, 123, 220, 10, 125, 96, 67, 62, 12, 202, 126, 71, 84, 113, 232, 178, 192, 218},
    {46, 38, 43, 106, 114, 176, 12, 69, 1, 21, 82, 27, 184, 109, 170, 0, 179, 25, 4, 145, 33, 61, 66, 223, 85, 238, 22, 23, 59, 64, 19, 174, 180, 240, 111, 128, 187, 65, 72, 35, 77, 221, 157, 172, 13, 197, 44, 229, 226, 130, 220, 49, 198, 24, 103, 76, 39, 211, 191, 115, 165, 206, 30, 7, 98, 156, 205, 181, 89, 252, 58, 138, 253, 104, 212, 236, 54, 224, 166, 155, 118, 8, 93, 140, 28, 95, 225, 248, 80, 182, 112, 63, 192, 116, 47, 217, 91, 84, 144, 53, 124, 117, 16, 73, 218, 254, 188, 18, 11, 107, 222, 5, 52, 129, 194, 173, 81, 9, 137, 246, 242, 143, 175, 147, 74, 195, 41, 133, 207, 120, 92, 17, 164, 169, 171, 48, 241, 57, 31, 83, 55, 96, 29, 185, 68, 232, 70, 148, 243, 209, 100, 214, 37, 244, 219, 131, 203, 139, 126, 183, 167, 199, 101, 159, 50, 230, 168, 45, 149, 123, 119, 87, 134, 75, 127, 67, 250, 228, 247, 135, 113, 60, 62, 177, 150, 121, 162, 227, 142, 34, 178, 42, 15, 160, 161, 216, 235, 234, 163, 186, 154, 141, 233, 208, 78, 151, 204, 190, 86, 152, 245, 239, 108, 196, 158, 210, 99, 237, 251, 3, 40, 90, 125, 132, 36, 215, 193, 71, 255, 200, 102, 56, 32, 136, 146, 79, 97, 110, 249, 20, 202, 231, 122, 88, 94, 6, 153, 105, 14, 10, 2, 201, 189, 213, 51, 26},
    {206, 165, 193, 37, 187, 108, 248, 246, 44, 139, 152, 201, 173, 214, 77, 72, 97, 35, 70, 24, 3, 79, 178, 175, 30, 66, 18, 198, 114, 125, 32, 210, 180, 224, 235, 28, 62, 136, 149, 227, 82, 147, 90, 119, 85, 199, 126, 121, 51, 20, 88, 4, 75, 101, 38, 151, 109, 115, 110, 223, 43, 17, 146, 249, 226, 26, 222, 232, 87, 195, 200, 131, 245, 81, 113, 157, 220, 12, 16, 184, 204, 192, 84, 31, 197, 215, 129, 94, 93, 181, 218, 194, 65, 148, 158, 112, 221, 34, 25, 33, 243, 78, 10, 67, 209, 6, 252, 196, 237, 42, 172, 164, 161, 244, 111, 191, 46, 170, 128, 69, 183, 212, 60, 99, 8, 122, 49, 86, 247, 96, 179, 57, 135, 106, 0, 58, 100, 202, 55, 98, 1, 254, 53, 155, 156, 83, 132, 9, 19, 171, 48, 95, 166, 68, 22, 104, 7, 14, 142, 211, 213, 50, 150, 234, 182, 203, 217, 64, 185, 163, 73, 45, 41, 118, 103, 134, 186, 230, 241, 250, 52, 207, 162, 124, 140, 116, 167, 228, 92, 63, 47, 176, 239, 238, 5, 216, 225, 188, 137, 160, 80, 231, 102, 11, 89, 91, 59, 23, 240, 105, 153, 177, 138, 219, 174, 123, 36, 159, 76, 21, 56, 242, 61, 107, 133, 143, 154, 130, 233, 15, 145, 255, 13, 189, 120, 251, 236, 117, 208, 190, 169, 168, 74, 229, 54, 2, 39, 127, 29, 253, 141, 71, 205, 40, 144, 27}};

static const unsigned char Dance_Box_Inverse[4][256] = {
    {15, 8, 250, 219, 18, 111, 245, 63, 81, 117, 249, 108, 6, 44, 248, 192, 102, 131, 107, 30, 239, 9, 26, 27, 53, 17, 255, 11, 84, 142, 62, 138, 232, 20, 189, 39, 224, 152, 1, 56, 220, 126, 191, 2, 46, 167, 0, 94, 135, 51, 164, 254, 112, 99, 76, 140, 231, 137, 70, 28, 181, 21, 182, 91, 29, 37, 22, 175, 144, 7, 146, 227, 38, 103, 124, 173, 55, 40, 204, 235, 88, 116, 10, 139, 97, 24, 208, 171, 243, 68, 221, 96, 130, 82, 244, 85, 141, 236, 64, 216, 150, 162, 230, 54, 73, 247, 3, 109, 212, 13, 237, 34, 90, 180, 4, 59, 93, 101, 80, 170, 129, 185, 242, 169, 100, 222, 158, 174, 35, 113, 49, 155, 223, 127, 172, 179, 233, 118, 71, 157, 83, 201, 188, 121, 98, 19, 234, 123, 147, 168, 184, 205, 209, 246, 200, 79, 65, 42, 214, 163, 193, 194, 186, 198, 132, 60, 78, 160, 166, 133, 14, 134, 43, 115, 31, 122, 5, 183, 190, 16, 32, 67, 89, 159, 12, 143, 199, 36, 106, 252, 207, 58, 92, 226, 114, 125, 213, 45, 52, 161, 229, 251, 240, 156, 206, 66, 61, 128, 203, 149, 215, 57, 74, 253, 151, 225, 195, 95, 104, 154, 50, 41, 110, 23, 77, 86, 48, 187, 177, 47, 165, 241, 145, 202, 197, 196, 75, 217, 25, 211, 33, 136, 120, 148, 153, 210, 119, 178, 87, 238, 176, 218, 69, 72, 105, 228},
    {160, 159, 176, 28, 36, 109, 178, 221, 197, 134, 241, 39, 246, 220, 143, 37, 219, 168, 79, 69, 96, 3, 104, 164, 135, 26, 77, 12, 182, 118, 186, 227, 78, 150, 205, 21, 236, 67, 23, 57, 30, 152, 68, 73, 87, 33, 98, 172, 141, 191, 222, 89, 40, 147, 215, 214, 1, 154, 114, 140, 117, 46, 245, 181, 94, 125, 175, 244, 196, 144, 29, 249, 198, 93, 183, 91, 75, 74, 180, 195, 84, 113, 237, 88, 250, 229, 192, 70, 92, 212, 83, 129, 170, 157, 189, 24, 243, 108, 126, 200, 218, 121, 107, 2, 54, 5, 208, 203, 130, 55, 179, 201, 224, 251, 59, 103, 233, 165, 7, 97, 22, 101, 82, 239, 119, 242, 248, 34, 105, 43, 124, 190, 153, 25, 238, 148, 174, 162, 138, 187, 132, 202, 42, 149, 209, 8, 51, 120, 85, 161, 80, 123, 131, 72, 188, 128, 230, 56, 65, 145, 139, 217, 15, 194, 106, 151, 90, 44, 116, 10, 166, 216, 111, 225, 199, 232, 58, 112, 253, 17, 231, 4, 223, 9, 53, 193, 211, 155, 48, 136, 14, 45, 254, 142, 163, 81, 100, 86, 66, 19, 158, 99, 247, 137, 213, 171, 20, 206, 76, 177, 204, 11, 226, 173, 228, 41, 6, 110, 255, 133, 240, 52, 102, 32, 122, 127, 49, 156, 210, 185, 71, 27, 252, 146, 115, 184, 60, 16, 31, 207, 61, 47, 13, 235, 18, 35, 0, 167, 234, 50, 38, 64, 95, 63, 62, 169},
    {15, 8, 250, 219, 18, 111, 245, 63, 81, 117, 249, 108, 6, 44, 248, 192, 102, 131, 107, 30, 239, 9, 26, 27, 53, 17, 255, 11, 84, 142, 62, 138, 232, 20, 189, 39, 224, 152, 1, 56, 220, 126, 191, 2, 46, 167, 0, 94, 135, 51, 164, 254, 112, 99, 76, 140, 231, 137, 70, 28, 181, 21, 182, 91, 29, 37, 22, 175, 144, 7, 146, 227, 38, 103, 124, 173, 55, 40, 204, 235, 88, 116, 10, 139, 97, 24, 208, 171, 243, 68, 221, 96, 130, 82, 244, 85, 141, 236, 64, 216, 150, 162, 230, 54, 73, 247, 3, 109, 212, 13, 237, 34, 90, 180, 4, 59, 93, 101, 80, 170, 129, 185, 242, 169, 100, 222, 158, 174, 35, 113, 49, 155, 223, 127, 172, 179, 233, 118, 71, 157, 83, 201, 188, 121, 98, 19, 234, 123, 147, 168, 184, 205, 209, 246, 200, 79, 65, 42, 214, 163, 193, 194, 186, 198, 132, 60, 78, 160, 166, 133, 14, 134, 43, 115, 31, 122, 5, 183, 190, 16, 32, 67, 89, 159, 12, 143, 199, 36, 106, 252, 207, 58, 92, 226, 114, 125, 213, 45, 52, 161, 229, 251, 240, 156, 206, 66, 61, 128, 203, 149, 215, 57, 74, 253, 151, 225, 195, 95, 104, 154, 50, 41, 110, 23, 77, 86, 48, 187, 177, 47, 165, 241, 145, 202, 197, 196, 75, 217, 25, 211, 33, 136, 120, 148, 153, 210, 119, 178, 87, 238, 176, 218, 69, 72, 105, 228},
    {134, 140, 245, 20, 51, 194, 105, 156, 124, 147, 102, 203, 77, 232, 157, 229, 78, 61, 26, 148, 49, 219, 154, 207, 19, 98, 65, 255, 35, 248, 24, 83, 30, 99, 97, 17, 216, 3, 54, 246, 253, 172, 109, 60, 8, 171, 116, 190, 150, 126, 161, 48, 180, 142, 244, 138, 220, 131, 135, 206, 122, 222, 36, 189, 167, 92, 25, 103, 153, 119, 18, 251, 15, 170, 242, 52, 218, 14, 101, 21, 200, 73, 40, 145, 82, 44, 127, 68, 50, 204, 42, 205, 188, 88, 87, 151, 129, 16, 139, 123, 136, 53, 202, 174, 155, 209, 133, 223, 5, 56, 58, 114, 95, 74, 28, 57, 185, 237, 173, 43, 234, 47, 125, 215, 183, 29, 46, 247, 118, 86, 227, 71, 146, 224, 175, 132, 37, 198, 212, 9, 184, 250, 158, 225, 254, 230, 62, 41, 93, 38, 162, 55, 10, 210, 226, 143, 144, 75, 94, 217, 199, 112, 182, 169, 111, 1, 152, 186, 241, 240, 117, 149, 110, 12, 214, 23, 191, 211, 22, 130, 32, 89, 164, 120, 79, 168, 176, 4, 197, 233, 239, 115, 81, 2, 91, 69, 107, 84, 27, 45, 70, 11, 137, 165, 80, 252, 0, 181, 238, 104, 31, 159, 121, 160, 13, 85, 195, 166, 90, 213, 76, 96, 66, 59, 33, 196, 64, 39, 187, 243, 177, 201, 67, 228, 163, 34, 236, 108, 193, 192, 208, 178, 221, 100, 113, 72, 7, 128, 6, 63, 179, 235, 106, 249, 141, 231}
};

static const unsigned char dance_table[2][4] = {{0, 1, 2, 3}, {2, 3, 0, 1}};
unsigned char dance_idx = 0;

/* System parameter */
static const unsigned int FK[4] = {0xa3b1bac6, 0x56aa3350, 0x677d9197, 0xb27022dc};

/* fixed parameter */
static const unsigned int CK[32] =
    {
        0x00070e15, 0x1c232a31, 0x383f464d, 0x545b6269,
        0x70777e85, 0x8c939aa1, 0xa8afb6bd, 0xc4cbd2d9,
        0xe0e7eef5, 0xfc030a11, 0x181f262d, 0x343b4249,
        0x50575e65, 0x6c737a81, 0x888f969d, 0xa4abb2b9,
        0xc0c7ced5, 0xdce3eaf1, 0xf8ff060d, 0x141b2229,
        0x30373e45, 0x4c535a61, 0x686f767d, 0x848b9299,
        0xa0a7aeb5, 0xbcc3cad1, 0xd8dfe6ed, 0xf4fb0209,
        0x10171e25, 0x2c333a41, 0x484f565d, 0x646b7279};

/*
 * private function:
 * look up in SboxTable and get the related value.
 * args:    [in] inch: 0x00~0xFF (8 bits unsigned value).
 */
static unsigned char sm4Sbox(unsigned char inch)
{
    unsigned char *pTable = (unsigned char *)SboxTable;
    unsigned char retVal = (unsigned char)(pTable[inch]);
    return retVal;
}

/*
 * private F(Lt) function:
 * "T algorithm" == "L algorithm" + "t algorithm".
 * args:    [in] a: a is a 32 bits unsigned value;
 * return: c: c is calculated with line algorithm "L" and nonline algorithm "t"
 */
static unsigned int sm4Lt(unsigned int ka)
{
    unsigned int bb = 0;
    unsigned int c = 0;
    unsigned char a[4];
    unsigned char b[4];
    PUT_UINT32_BE(ka, a, 0)
    b[0] = sm4Sbox(a[0]);
    b[1] = sm4Sbox(a[1]);
    b[2] = sm4Sbox(a[2]);
    b[3] = sm4Sbox(a[3]);
    GET_UINT32_BE(bb, b, 0)
    c = bb ^ (ROTL(bb, 2)) ^ (ROTL(bb, 10)) ^ (ROTL(bb, 18)) ^ (ROTL(bb, 24));
    return c;
}

// static unsigned int sm4Lt_inverse(unsigned int c)
// {
//     unsigned int bb = 0;
//     unsigned int ka = 0;
//     unsigned char a[4];
//     unsigned char b[4];
//     PUT_UINT32_BE(c, a, 0)
//     b[0] = SM4_BOXES_TABLE_INVERSE[a[0]];
//     b[1] = SM4_BOXES_TABLE_INVERSE[a[1]];
//     b[2] = SM4_BOXES_TABLE_INVERSE[a[2]];
//     b[3] = SM4_BOXES_TABLE_INVERSE[a[3]];
//     GET_UINT32_BE(bb, b, 0)
//     ka = bb ^ (ROTL(bb, 2)) ^ (ROTL(bb, 10)) ^ (ROTL(bb, 18)) ^ (ROTL(bb, 24));
//     return ka;
// }

/*
 * private F function:
 * Calculating and getting encryption/decryption contents.
 * args:    [in] x0: original contents;
 * args:    [in] x1: original contents;
 * args:    [in] x2: original contents;
 * args:    [in] x3: original contents;
 * args:    [in] rk: encryption/decryption key;
 * return the contents of encryption/decryption contents.
 */
static unsigned int sm4F(unsigned int x0, unsigned int x1, unsigned int x2, unsigned int x3, unsigned int rk)
{
    return (x0 ^ sm4Lt(x1 ^ x2 ^ x3 ^ rk));
}

/* private function:
 * Calculating round encryption key.
 * args:    [in] a: a is a 32 bits unsigned value;
 * return: sk[i]: i{0,1,2,3,...31}.
 */
static unsigned int sm4CalciRK(unsigned int ka)
{
    unsigned int bb = 0;
    unsigned int rk = 0;
    unsigned char a[4];
    unsigned char b[4];
    PUT_UINT32_BE(ka, a, 0)
    b[0] = sm4Sbox(a[0]);
    b[1] = sm4Sbox(a[1]);
    b[2] = sm4Sbox(a[2]);
    b[3] = sm4Sbox(a[3]);
    GET_UINT32_BE(bb, b, 0)
    rk = bb ^ (ROTL(bb, 13)) ^ (ROTL(bb, 23));
    return rk;
}

static void sm4_setkey(unsigned int SK[32], unsigned char key[16])
{
    unsigned int MK[4];
    unsigned int k[36];
    unsigned int i = 0;

    GET_UINT32_BE(MK[0], key, 0);
    GET_UINT32_BE(MK[1], key, 4);
    GET_UINT32_BE(MK[2], key, 8);
    GET_UINT32_BE(MK[3], key, 12);
    k[0] = MK[0] ^ FK[0];
    k[1] = MK[1] ^ FK[1];
    k[2] = MK[2] ^ FK[2];
    k[3] = MK[3] ^ FK[3];
    for (; i < 32; i++)
    {
        k[i + 4] = k[i] ^ (sm4CalciRK(k[i + 1] ^ k[i + 2] ^ k[i + 3] ^ CK[i]));
        SK[i] = k[i + 4];
    }
}

static void sm4_set_rkey(unsigned int SK[32], unsigned int key[32])
{
    memcpy(SK, key, 32 * sizeof(unsigned int));
}

static void dance()
{
    dance_idx = (dance_idx + 1) % 2;
}

// static void pfunc(unsigned char ulbuf[16]){
//     for (int i = 0; i < 4; i++)
//     {
//         int box_idx = dance_table[dance_idx][i];
//         for (int j = 0; j<4; j++)
//         {
//             ulbuf[i*4+j] = rot18(Dance_Box[box_idx][ulbuf[i*4+j]],j+3);
//         }
//     }
// }

static void pfunc(unsigned int ulbuf[4])
{
    unsigned char a[4];
    unsigned char b[4];
    for (unsigned char i = 0; i < 4; i++)
    {
        int box_idx = dance_table[dance_idx][i];
        PUT_UINT32_BE(ulbuf[i], a, 0)
        for (int j = 0; j < 4; j++)
        {
            a[j] = (unsigned char)Dance_Box[box_idx][a[j]];
            b[j] = rot18(a[j], j + 3);
        }
        GET_UINT32_BE(ulbuf[i], b, 0)
    }
}

static void pfunc_inverse(unsigned int ulbuf[4])
{
    // the ulbuf is in reverse order
    unsigned char a[4];
    unsigned char b[4];
    for (unsigned char i = 0; i < 4; i++)
    {
        int box_idx = dance_table[dance_idx][3 - i];
        PUT_UINT32_BE(ulbuf[i], a, 0)
        for (int j = 0; j < 4; j++)
        {
            a[j] = rot18(a[j], 5 - j);
            b[j] = (unsigned char)Dance_Box_Inverse[box_idx][a[j]];
        }
        GET_UINT32_BE(ulbuf[i], b, 0)
    }
}

void inverse_one_round(unsigned int state[4], unsigned int sk, unsigned int dancebox_index)
{
    dance_idx = dancebox_index;
    pfunc_inverse(state);
    unsigned int prev = sm4F(state[0], state[1], state[2], state[3], sk);
    for (int i = 0; i < 3; i++)
    {
        state[i] = state[i+1];
    }
    state[3] = prev;
}

void inverse_one_round_raw(unsigned char ct[16], unsigned int sk, unsigned int dancebox_index)
{
    dance_idx = dancebox_index;
    unsigned int state[4];
    GET_UINT32_BE(state[0], ct, 0);
    GET_UINT32_BE(state[1], ct, 4);
    GET_UINT32_BE(state[2], ct, 8);
    GET_UINT32_BE(state[3], ct, 12);

    pfunc_inverse(state);
    unsigned int prev = sm4F(state[0], state[1], state[2], state[3], sk);
    for (int i = 0; i < 3; i++)
    {
        state[i] = state[i+1];
    }
    state[3] = prev;

    PUT_UINT32_BE(state[0], ct, 0);
    PUT_UINT32_BE(state[1], ct, 4);
    PUT_UINT32_BE(state[2], ct, 8);
    PUT_UINT32_BE(state[3], ct, 12);
}


/*
 * SM4 standard one round processing
 *
 */
static void sm4_one_round(unsigned int sk[32],
                          unsigned char input[16],
                          unsigned char output[16],
                          unsigned int dance_time)
{
    unsigned int i = 0;
    unsigned int ulbuf[36];
    dance_idx = 0;

    memset(ulbuf, 0, sizeof(ulbuf));
    GET_UINT32_BE(ulbuf[0], input, 0)
    GET_UINT32_BE(ulbuf[1], input, 4)
    GET_UINT32_BE(ulbuf[2], input, 8)
    GET_UINT32_BE(ulbuf[3], input, 12)
    while (i < 32)
    {
        if (i == dance_time)
        {
            dance();
        }
        ulbuf[i + 4] = sm4F(ulbuf[i], ulbuf[i + 1], ulbuf[i + 2], ulbuf[i + 3], sk[i]);
        // pfunc((unsigned char *)(ulbuf + i + 1));
        pfunc(ulbuf + i + 1);
        i++;
    }
    dance();
    PUT_UINT32_BE(ulbuf[35], output, 0);
    PUT_UINT32_BE(ulbuf[34], output, 4);
    PUT_UINT32_BE(ulbuf[33], output, 8);
    PUT_UINT32_BE(ulbuf[32], output, 12);
}


static void dec_sm4_one_round(unsigned int sk[32],
                          unsigned char input[16],
                          unsigned char output[16],
                          unsigned int dance_time)
{
    unsigned int i = 0;
    unsigned int ulbuf[36];
    dance_idx = 1;

    memset(ulbuf, 0, sizeof(ulbuf));
    GET_UINT32_BE(ulbuf[0], input, 0)
    GET_UINT32_BE(ulbuf[1], input, 4)
    GET_UINT32_BE(ulbuf[2], input, 8)
    GET_UINT32_BE(ulbuf[3], input, 12)
    while (i < 32)
    {
        if (i == 32 - dance_time)
        {
            dance();
        }
        pfunc_inverse(ulbuf + i + 1);
        ulbuf[i + 4] = sm4F(ulbuf[i], ulbuf[i + 1], ulbuf[i + 2], ulbuf[i + 3], sk[i]);
        i++;
    }
    dance();
    PUT_UINT32_BE(ulbuf[35], output, 0);
    PUT_UINT32_BE(ulbuf[34], output, 4);
    PUT_UINT32_BE(ulbuf[33], output, 8);
    PUT_UINT32_BE(ulbuf[32], output, 12);
}

/*
 * SM4 standard one round processing
 *
 */
static void _sm4_one_round(unsigned int sk[32],
                          unsigned char input[16],
                          unsigned char output[16],
                          unsigned int dance_time)
{
    unsigned int i = 0;
    unsigned int ulbuf[36];

    memset(ulbuf, 0, sizeof(ulbuf));
    GET_UINT32_BE(ulbuf[0], input, 0)
    GET_UINT32_BE(ulbuf[1], input, 4)
    GET_UINT32_BE(ulbuf[2], input, 8)
    GET_UINT32_BE(ulbuf[3], input, 12)
    while (i < 32)
    {
        if (i == dance_time)
        {
            dance();
        }
        printf("rk(%02d) = 0x%08x \n", i, sk[i]);
        for (int j = 0; j < 4; j++)
        {
            printf("%08x ", ulbuf[i + j]);
        }
        printf("\n");
        
        ulbuf[i + 4] = sm4F(ulbuf[i], ulbuf[i + 1], ulbuf[i + 2], ulbuf[i + 3], sk[i]);
        // pfunc((unsigned char *)(ulbuf + i + 1));
        pfunc(ulbuf + i + 1);

        unsigned int state[4];
        for (int j = 0; j < 4; j++)
        {
            state[3 - j] = ulbuf[i + j + 1];
        }

        printf("State init: ");
        for (int j = 0; j < 4; j++)
        {
            printf("%08x ", state[j]);
        }
        printf("\n");

        inverse_one_round(state, sk[i], dance_idx);
        printf("State after inverse: ");
        for (int j = 0; j < 4; j++)
        {
            printf("%08x ", state[j]);
        }
        printf("\n");
        i++;
    }
    dance();
    PUT_UINT32_BE(ulbuf[35], output, 0);
    PUT_UINT32_BE(ulbuf[34], output, 4);
    PUT_UINT32_BE(ulbuf[33], output, 8);
    PUT_UINT32_BE(ulbuf[32], output, 12);
}


/*
 * SM4 key schedule (128-bit, encryption)
 */
void sm4_setkey_enc(sm4_context *ctx, unsigned char key[16])
{
    ctx->mode = SM4_ENCRYPT;
    sm4_setkey(ctx->sk, key);
}

void sm4_set_roundkey_enc(sm4_context *ctx, unsigned int rkey[32])
{
    ctx->mode = SM4_ENCRYPT;
    sm4_set_rkey(ctx->sk, rkey);
}

/*
 * SM4 key schedule (128-bit, decryption)
 */
void sm4_setkey_dec(sm4_context *ctx, unsigned char key[16])
{
    int i;
    ctx->mode = SM4_ENCRYPT;
    sm4_setkey(ctx->sk, key);
    for (i = 0; i < 16; i++)
    {
        SWAP(ctx->sk[i], ctx->sk[31 - i]);
    }
}

void sm4_set_roundkey_dec(sm4_context *ctx, unsigned int rkey[32])
{
    int i;
    ctx->mode = SM4_ENCRYPT;
    sm4_set_rkey(ctx->sk, rkey);
    for (i = 0; i < 16; i++)
    {
        SWAP(ctx->sk[i], ctx->sk[31 - i]);
    }
}

/*
 * SM4-ECB block encryption/decryption
 */

void sm4_crypt_ecb(sm4_context *ctx,
                   int mode,
                   int length,
                   unsigned int dance_time,
                   unsigned char *input,
                   unsigned char *output)
{
    while (length > 0)
    {
        sm4_one_round(ctx->sk, input, output, dance_time);
        input += 16;
        output += 16;
        length -= 16;
    }
}

void test_my_brute_way()
{
    unsigned char key[16] = {0x01, 0x23, 0x45, 0x67, 
                             0x89, 0xab, 0xcd, 0xef, 
                             0xfe, 0xdc, 0xba, 0x98, 
                             0x76, 0x54, 0x32, 0x10};
    unsigned char plaintext[16] = "testmyencryption";
    unsigned char ciphertext1[16];
    unsigned char ciphertext2[16];

    int i;

    printf("Key: ");
    for(i = 0; i < 16; i++)
        printf("%02x", key[i]);
    printf("\n");

    printf("Plaintext: ");
    for(i = 0; i < 16; i++)
        printf("%02x", plaintext[i]);
    printf("\n");

    sm4_context ctx;
    sm4_setkey_enc(&ctx, key);
    sm4_crypt_ecb(&ctx, 1, 16, 31, plaintext, ciphertext1);
    sm4_crypt_ecb(&ctx, 1, 16, 30, plaintext, ciphertext2);

    printf("Ciphertext1: ");
    for(i = 0; i < 16; i++)
        printf("%02x", ciphertext1[i]);
    printf("\n");

    printf("Ciphertext2: ");
    for(i = 0; i < 16; i++)
        printf("%02x", ciphertext2[i]);
    printf("\n");


    unsigned int SK[32];
    sm4_setkey(SK, key);

    unsigned int state1[4];
    unsigned int state2[4];
    GET_UINT32_BE(state1[0], ciphertext1, 0);
    GET_UINT32_BE(state1[1], ciphertext1, 4);
    GET_UINT32_BE(state1[2], ciphertext1, 8);
    GET_UINT32_BE(state1[3], ciphertext1, 12);
    GET_UINT32_BE(state2[0], ciphertext2, 0);
    GET_UINT32_BE(state2[1], ciphertext2, 4);
    GET_UINT32_BE(state2[2], ciphertext2, 8);
    GET_UINT32_BE(state2[3], ciphertext2, 12);
    
    inverse_one_round(state1, SK[31], 1);
    inverse_one_round(state2, SK[31], 1);
    dance_idx = 0;
    pfunc_inverse(state1);
    dance_idx = 1;
    pfunc_inverse(state2);
    if (state1[0] == state2[0] && state1[1] == state2[1] && 
        state1[2] == state2[2] && state1[3] == state2[3])
    {
        printf("Brute force is OK!\n");
    }

    unsigned int sk = brute_round_key(ciphertext1, ciphertext2, 
                        SK[31] - (1<<20), SK[31] + (1<<20));
    printf("Brute force key: %08x\n", sk);
}


unsigned int brute_round_key(unsigned char ct1[16], unsigned char ct2[16], 
                            unsigned int st, unsigned int ed)
{
    // ct1, dance time = 31
    // ct2, dance time = 30
    unsigned int state1[4];
    unsigned int state2[4];
    unsigned int sk = st;
    unsigned int space = ed - st;
    printf("Brute force interval:  %08x - %08x !\n", st, ed);
    for (; sk < ed; sk++)
    {
        // log process by sk / 0xffffffff
        if (sk % (1<<16) == 0)
        {
            printf("\r process : %08x / %08x", sk, space);
        }

        // memcpy(state1, ct1, sizeof(unsigned int) * 4);
        // memcpy(state2, ct2, sizeof(unsigned int) * 4);
        GET_UINT32_BE(state1[0], ct1, 0);
        GET_UINT32_BE(state1[1], ct1, 4);
        GET_UINT32_BE(state1[2], ct1, 8);
        GET_UINT32_BE(state1[3], ct1, 12);
        GET_UINT32_BE(state2[0], ct2, 0);
        GET_UINT32_BE(state2[1], ct2, 4);
        GET_UINT32_BE(state2[2], ct2, 8);
        GET_UINT32_BE(state2[3], ct2, 12);
        inverse_one_round(state1, sk, 1);
        inverse_one_round(state2, sk, 1);
        dance_idx = 0;
        pfunc_inverse(state1);
        dance_idx = 1;
        pfunc_inverse(state2);
        if (state1[0] == state2[0] && state1[1] == state2[1] && 
            state1[2] == state2[2] && state1[3] == state2[3])
        {
            // log sk
            printf("\n");
            printf("find key : %08x\n", sk);
            // saved to file
            // return sk;
        }
    } 
    printf("\n");
    printf("Brute force failed!\n");
    return 0;
}

unsigned int brute_round_key_with_verify(
    unsigned char ct1[16], unsigned char ct2[16], 
    unsigned char v1[16], unsigned char v2[16], 
    unsigned int st, unsigned int ed)
{
    // ct1, dance time = 31
    // ct2, dance time = 30
    unsigned int state1[4];
    unsigned int state2[4];
    unsigned int sk = st;
    unsigned int space = ed - st;
    printf("Brute force interval:  %08x - %08x !\n", st, ed);
    for (; sk < ed; sk++)
    {
        // log process by sk / 0xffffffff
        if (sk % (1<<16) == 0)
        {
            printf("\rprocess : %08x / %08x", sk, space);
        }

        // memcpy(state1, ct1, sizeof(unsigned int) * 4);
        // memcpy(state2, ct2, sizeof(unsigned int) * 4);
        GET_UINT32_BE(state1[0], ct1, 0);
        GET_UINT32_BE(state1[1], ct1, 4);
        GET_UINT32_BE(state1[2], ct1, 8);
        GET_UINT32_BE(state1[3], ct1, 12);
        GET_UINT32_BE(state2[0], ct2, 0);
        GET_UINT32_BE(state2[1], ct2, 4);
        GET_UINT32_BE(state2[2], ct2, 8);
        GET_UINT32_BE(state2[3], ct2, 12);
        inverse_one_round(state1, sk, 1);
        inverse_one_round(state2, sk, 1);
        dance_idx = 0;
        pfunc_inverse(state1);
        dance_idx = 1;
        pfunc_inverse(state2);
        if (state1[0] == state2[0] && state1[1] == state2[1] && 
            state1[2] == state2[2] && state1[3] == state2[3])
        {
            // printf("\n");
            // printf("possible key : 0x%08x\n", sk);
            // verify
            unsigned int state3[4];
            unsigned int state4[4];
            GET_UINT32_BE(state3[0], v1, 0);
            GET_UINT32_BE(state3[1], v1, 4);
            GET_UINT32_BE(state3[2], v1, 8);
            GET_UINT32_BE(state3[3], v1, 12);
            GET_UINT32_BE(state4[0], v2, 0);
            GET_UINT32_BE(state4[1], v2, 4);
            GET_UINT32_BE(state4[2], v2, 8);
            GET_UINT32_BE(state4[3], v2, 12);
            inverse_one_round(state3, sk, 1);
            inverse_one_round(state4, sk, 1);
            dance_idx = 0;
            pfunc_inverse(state3);
            dance_idx = 1;
            pfunc_inverse(state4);
            if (state3[0] == state4[0] && state3[1] == state4[1] && 
                state3[2] == state4[2] && state3[3] == state4[3])
            {
                // log sk
                printf("\n");
                printf("round key = 0x%08x\n", sk);
                // saved to file
                return sk;
            }
        }
    } 
    printf("\n");
    printf("Brute force failed!\n");
    return 0;
}