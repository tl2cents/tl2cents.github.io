from out_public import *
from Crypto.Util.number import *
# modulo x**n - 1
n = 543

# circle shift left
def cshift(a: int, shift: int) -> int:
    """Cyclic shift left b bits of a."""
    return ((a << shift) | (a >> (n - shift))) & ((1 << n) - 1)

# polynomial multiplication in GF(2) modulo x**n - 1
def pmul(a: int, b: int) -> int:
    """Multiply two polynomials in GF(2) modulo x**n - 1."""
    c = 0
    for i in range(n):
        if a & 1:
            c ^= b
        a >>= 1
        b = cshift(b, 1)
        # print(f"i = {i}, a = {a}, b = {b}, c = {c}")
    return c

def m_mul(a: int,b: int) -> int:
    """ matrix multiplication in GF(2)"""
    return bin(a&b)[2:].count('1')%2

def m_encode(M: list, a: int) -> int:
    return int("".join([str(m_mul(a, b)) for b in M]),2)

# target = 12504369687771304731329659908415618240539599101822179213191415689029570432404161444078887179501488034412507694477270188085236065908298717759703389396565314149897564
# secret = 9809570453264748617729173272798292415295067216928719477


subset = out
m = len(subset)
M = ms[:]

print("[+] known : M, subset , encoded_target")
print("[+] unknown : target, secret")

# check subset product

secret = int(input("secret: "))

result = 1
for i in range(m):
    if (secret>>i)&1:
        result = pmul(result, subset[i])
    

# check if target is correctly encoded
encoded_target_no_error = m_encode(M, result)
err_bits = encoded_target_no_error ^ bytes_to_long(encoded_target)
err_num = bin(err_bits).count('1')
print(f"[+] {err_num = }")
assert err_num <= 10, "too many errors"
print(f"[+] check error bits ? True")