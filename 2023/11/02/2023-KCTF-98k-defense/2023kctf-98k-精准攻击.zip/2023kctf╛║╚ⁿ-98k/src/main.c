#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <fcntl.h>
#include <unistd.h>

typedef unsigned long long ullong;

// #define ARR_CONTAINER unsigned char
#define ARR_CONTAINER ullong
#define ARR_CONTAINER_SIZE sizeof(ARR_CONTAINER)
#define ARR_CONTAINER_BIT (ARR_CONTAINER_SIZE * 8)
// #define N 256
#define N 543
#define ARR_LEN ((N + ARR_CONTAINER_BIT - 1) / ARR_CONTAINER_BIT)
#define EXTRA_BITS (ARR_CONTAINER_BIT * ARR_LEN - N)

typedef struct BitVec {
	ARR_CONTAINER arr[ARR_LEN];
} BitVec;

void BitVec_printhex(BitVec* bv) {
	// printf("0x");
	int i = ARR_LEN - 1;
	while (i > 0 && bv->arr[i] == 0) i--;
	printf("%llx", bv->arr[i]);
	for (i -= 1; i >= 0; i--) {
		printf("%016llx", bv->arr[i]);
	}
	putchar('\n');
}

void BitVec_shr(BitVec* out, BitVec* in, size_t n) {
	size_t container_offset = n / ARR_CONTAINER_BIT;
	size_t bit_offset = n % ARR_CONTAINER_BIT;
	for (int i = 0; i < ARR_LEN - container_offset - 1; i++) {
		out->arr[i] = (in->arr[i + container_offset] >> bit_offset);
		if (bit_offset) {
			out->arr[i] |= (in->arr[i + container_offset + 1] << (ARR_CONTAINER_BIT - bit_offset));
		}
	}
	out->arr[ARR_LEN - container_offset - 1] = in->arr[ARR_LEN - 1] >> bit_offset;
	for (int i = ARR_LEN - container_offset; i < ARR_LEN; i++)
		out->arr[i] = 0;
}

void BitVec_shl(BitVec* out, BitVec* in, size_t n) {
	size_t container_offset = n / ARR_CONTAINER_BIT;
	size_t bit_offset = n % ARR_CONTAINER_BIT;
	for (int i = ARR_LEN - 1; i >= container_offset + 1; i--) {
		out->arr[i] = (in->arr[i - container_offset] << bit_offset);
		if (bit_offset) {
			out->arr[i] |= (in->arr[i - container_offset - 1] >> (ARR_CONTAINER_BIT - bit_offset));
		}
	}
	out->arr[container_offset] = in->arr[0] << bit_offset;
	for (int i = 0; i < container_offset; i++)
		out->arr[i] = 0;
	out->arr[ARR_LEN - 1] &= (1l << (ARR_CONTAINER_BIT - EXTRA_BITS)) - 1;
}

void BitVec_and(BitVec* out, BitVec* in_a, BitVec* in_b) {
	for (int i = 0; i < ARR_LEN; i++) {
		out->arr[i] = in_a->arr[i] & in_b->arr[i];
	}
}

void BitVec_or(BitVec* out, BitVec* in_a, BitVec* in_b) {
	for (int i = 0; i < ARR_LEN; i++) {
		out->arr[i] = in_a->arr[i] | in_b->arr[i];
	}
}

void BitVec_xor(BitVec* out, BitVec* in_a, BitVec* in_b) {
	for (int i = 0; i < ARR_LEN; i++) {
		out->arr[i] = in_a->arr[i] ^ in_b->arr[i];
	}
}

void BitVec_rol(BitVec* out, BitVec* in, size_t n) {
	BitVec temp;
	BitVec_shl(&temp, in, n);
	BitVec_shr(out, in, N - n);
	BitVec_or(out, out, &temp);
}

#define BitVec_ror(out, in, n) BitVec_rol(out, in, (N - (n)))

void BitVec_getrandom(BitVec* bv) {
	int fd = open("/dev/urandom", 0);
	read(fd, bv, sizeof(BitVec));
	close(fd);
	bv->arr[ARR_LEN - 1] &= (1l << (ARR_CONTAINER_BIT - EXTRA_BITS)) - 1;
	/*
	for (int i = 0; i < EXTRA_BITS; i++) {
		assert(((bv->arr[ARR_LEN - 1] >> (ARR_CONTAINER_BIT - 1 - i)) & 1) == 0);
	}
	/**/
}

void BitVec_mul(BitVec* out, BitVec* in_a, BitVec* in_b) {
	BitVec a, b;
	memcpy(&a, in_a, sizeof(BitVec));
	memcpy(&b, in_b, sizeof(BitVec));
	memset(out, 0, sizeof(BitVec));
	for (int i = 0; i < N; i++) {
		if (a.arr[0] & 1) {
			BitVec_xor(out, out, &b);
		}
		BitVec_shr(&a, &a, 1);
		BitVec_rol(&b, &b, 1);
	}
}

int BitVec_inner_product(BitVec* a, BitVec* b) {
	int s = 0;
	for (int i = 0; i < ARR_LEN; i++) {
		s += __builtin_popcountll(a->arr[i] & b->arr[i]);
	}
	return s & 1;
}

int BitVec_count1(BitVec* bv) {
	int s = 0;
	for (int i = 0; i < ARR_LEN; i++) {
		s += __builtin_popcountll(bv->arr[i]);
	}
	return s;
}

void BitVec_encode(BitVec* out, BitVec* M, int n, BitVec* a) {
	memset(out, 0, sizeof(BitVec));
	// assert(n < N);
	for (int i = 0; i < n; i++) {
		BitVec_shl(out, out, 1);
		out->arr[0] |= BitVec_inner_product(a, M + i);
	}
}

int BitVec_fromhex(BitVec* out, const char* s, int len) {
	memset(out, 0, sizeof(BitVec));
	for (int i = 0; i < len; i++) {
		char c = s[i];
		if (c >= '0' && c <= '9') {
			c = c - '0';
		} else if (c >= 'a' && c <= 'f') {
			c = c - 'a' + 10;
		} else {
			return 0;
		}
		BitVec_shl(out, out, 4);
		out->arr[0] |= c;
	}
	return 1;
}

#include "values.h"

int main() {
	char input[512];
	memset(input, 0, sizeof(input));
	read(0, input, 511);
	int len = strlen(input);
	if (input[len - 1] == '\n') {
		input[len - 1] = 0;
		len--;
	}
	
	// KCTF{0-9a-f}
	#define LENGTH ((sizeof(out) / sizeof(BitVec) + 3) / 4)
	#define EXPECTED_LENGTH ((int) (6 + LENGTH))
	if (len != EXPECTED_LENGTH || input[0] != 'K' || input[1] != 'C' || input[2] != 'T' || input[3] != 'F' || input[4] != '{' || input[len - 1] != '}') {
	_fail:
		write(2, "No\n", 3);
		exit(1);
	}

	// input secret
	BitVec secret, target;
	if (!BitVec_fromhex(&secret, input + 5, LENGTH)) goto _fail;
	memset(&target, 0, sizeof(BitVec));
	target.arr[0] = 1;
	for (int i = 0; i < sizeof(out) / sizeof(BitVec); i++) {
		if (secret.arr[0] & 1) {
			BitVec_mul(&target, &target, out + i);
		}
		BitVec_shr(&secret, &secret, 1);
	}

	// check target
	// assert(N >= sizeof(ms) / sizeof(BitVec) / 2);
	BitVec tmp;
	BitVec_encode(&tmp, ms, sizeof(ms) / sizeof(BitVec) / 2, &target);
	BitVec_xor(&tmp, &tmp, encoded_target);
	int err_num = BitVec_count1(&tmp);
	printf("%d\n", err_num);
	BitVec_encode(&tmp, ms + sizeof(ms) / sizeof(BitVec) / 2, sizeof(ms) / sizeof(BitVec) / 2, &target);
	BitVec_xor(&tmp, &tmp, encoded_target + 1);
	err_num += BitVec_count1(&tmp);
	printf("%d\n", err_num);
	if (err_num > 10) goto _fail;

	write(1, "Ye\n", 3);
}

// KCTF{666aac797b125dbdcdfdd46ca066ced4ac1cc9f1824275}
